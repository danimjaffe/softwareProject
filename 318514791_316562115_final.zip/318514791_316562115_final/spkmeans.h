#ifndef SOFTWAREPROJECT_SPKMEANS_H
#define SOFTWAREPROJECT_SPKMEANS_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <assert.h>
#include "userInput.h"
#include "eigengapHeuristic.h"

#endif
